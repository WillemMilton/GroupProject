﻿' ********************************************************************************* 
'  TEAM NUMBER: 13
'  Member 1: MONCHO, R.M (216028656)
'  Member 2: SEKGOTO, N.L (218031731)
'  Member 3: NTOAMPE, L.H (201314444)
'  Member 4: MJEKULA, C (218076052)
'  Class name: frmFreeStateGranniesSocialSavings
' *********************************************************************************
Option Strict On
Option Explicit On
Option Infer Off
Public Class frmFreeStateGranniesSocialSavings
    Private Members() As Member
    Private NumOfMember As Integer
    Private Sub frmFreeStateGranniesSocialSavings_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        MsgBox("Please Set The interest rate before Entering any Information")
    End Sub
    ' Subroutine for displaying the information on the grid
    Private Sub DisplayInfo(ByVal r As Integer, ByVal c As Integer, ByVal t As String)
        grdSocialSavings.Row = r
        grdSocialSavings.Col = c
        grdSocialSavings.Text = t
    End Sub

    Private Sub btnMembersRecords_Click(sender As Object, e As EventArgs) Handles btnMembersRecords.Click
        ' get the number of members 
        NumOfMember = CInt(InputBox("How many member's you want to add?"))
        ReDim Members(NumOfMember)
        ' Instanstiate a member class
        Dim myMember As Member
        myMember = New Member(NumOfMember)
        ' Loop for storing the info of all member's 
        For x As Integer = 1 To NumOfMember
            myMember.Surname = InputBox("What's the Surname of Member " & CStr(x) & "?")
            myMember.Name = InputBox("What's the Name of Member " & CStr(x) & "?")
            myMember.Age = CInt(InputBox("How Old is " & myMember.Name & " " & myMember.Surname & "?"))
            myMember.BirthDay = InputBox("Please Enter " & myMember.Name & " " & myMember.Surname & "Birthday in the Format YYYY/MM/DD ")
            myMember.IDnumber = CInt(InputBox("Please Enter " & myMember.Name & "'s  ID Number"))


        Next x

    End Sub
End Class