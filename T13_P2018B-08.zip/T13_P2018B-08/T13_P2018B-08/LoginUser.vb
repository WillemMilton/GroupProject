﻿' ********************************************************************************* 
'  TEAM NUMBER: 13
'  Member 1: MONCHO, R.M (216028656)
'  Member 2: SEKGOTO, N.L (218031731)
'  Member 3: NTOAMPE, L.H (201314444)
'  Member 4: MJEKULA, C (218076052)
'  Class name: frmLogin
' *********************************************************************************
Option Strict On
Option Explicit On
Option Infer Off

Public MustInherit Class LoginUser
    Protected _Username As String
    Protected _Password As String

    ' Property method for the username 
    Public Property Username As String
        Get
            Return _Username
        End Get
        Set(value As String)
            _Username = value
        End Set
    End Property

    ' property method for the password
    Public Property Password As String
        Get
            Return _Password
        End Get
        Set(value As String)
            _Password = value
        End Set
    End Property

    ' method to verifying the password and username 
    Public MustOverride Sub Verify()
End Class
