﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFreeStateGranniesSocialSavings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnChangeInterest = New System.Windows.Forms.Button()
        Me.btnMembersRecords = New System.Windows.Forms.Button()
        Me.btnRemoveMember = New System.Windows.Forms.Button()
        Me.btnBorrowedMoney = New System.Windows.Forms.Button()
        Me.btnBorrowMoney = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnChangeInterest
        '
        Me.btnChangeInterest.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnChangeInterest.Location = New System.Drawing.Point(34, 13)
        Me.btnChangeInterest.Name = "btnChangeInterest"
        Me.btnChangeInterest.Size = New System.Drawing.Size(99, 35)
        Me.btnChangeInterest.TabIndex = 0
        Me.btnChangeInterest.Text = "Change Interest Rate"
        Me.btnChangeInterest.UseVisualStyleBackColor = False
        '
        'btnMembersRecords
        '
        Me.btnMembersRecords.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnMembersRecords.Location = New System.Drawing.Point(34, 68)
        Me.btnMembersRecords.Name = "btnMembersRecords"
        Me.btnMembersRecords.Size = New System.Drawing.Size(99, 37)
        Me.btnMembersRecords.TabIndex = 1
        Me.btnMembersRecords.Text = "Add Member"
        Me.btnMembersRecords.UseVisualStyleBackColor = False
        '
        'btnRemoveMember
        '
        Me.btnRemoveMember.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnRemoveMember.Location = New System.Drawing.Point(171, 68)
        Me.btnRemoveMember.Name = "btnRemoveMember"
        Me.btnRemoveMember.Size = New System.Drawing.Size(119, 37)
        Me.btnRemoveMember.TabIndex = 2
        Me.btnRemoveMember.Text = "Remove Member"
        Me.btnRemoveMember.UseVisualStyleBackColor = False
        '
        'btnBorrowedMoney
        '
        Me.btnBorrowedMoney.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnBorrowedMoney.Location = New System.Drawing.Point(171, 13)
        Me.btnBorrowedMoney.Name = "btnBorrowedMoney"
        Me.btnBorrowedMoney.Size = New System.Drawing.Size(119, 35)
        Me.btnBorrowedMoney.TabIndex = 3
        Me.btnBorrowedMoney.Text = "Check Who Still Owes Money"
        Me.btnBorrowedMoney.UseVisualStyleBackColor = False
        '
        'btnBorrowMoney
        '
        Me.btnBorrowMoney.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.btnBorrowMoney.Location = New System.Drawing.Point(326, 13)
        Me.btnBorrowMoney.Name = "btnBorrowMoney"
        Me.btnBorrowMoney.Size = New System.Drawing.Size(111, 34)
        Me.btnBorrowMoney.TabIndex = 4
        Me.btnBorrowMoney.Text = "Borrow Money"
        Me.btnBorrowMoney.UseVisualStyleBackColor = False
        '
        'frmFreeStateGranniesSocialSavings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnBorrowMoney)
        Me.Controls.Add(Me.btnBorrowedMoney)
        Me.Controls.Add(Me.btnRemoveMember)
        Me.Controls.Add(Me.btnMembersRecords)
        Me.Controls.Add(Me.btnChangeInterest)
        Me.Name = "frmFreeStateGranniesSocialSavings"
        Me.Text = "The Free State Grannies Social Savings"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnChangeInterest As Button
    Friend WithEvents btnMembersRecords As Button
    Friend WithEvents btnRemoveMember As Button
    Friend WithEvents btnBorrowedMoney As Button
    Friend WithEvents btnBorrowMoney As Button
End Class
