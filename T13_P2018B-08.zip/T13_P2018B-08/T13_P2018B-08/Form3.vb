﻿' ********************************************************************************* 
'  TEAM NUMBER: 13
'  Member 1: MONCHO, R.M (216028656)
'  Member 2: SEKGOTO, N.L (218031731)
'  Member 3: NTOAMPE, L.H (201314444)
'  Member 4: MJEKULA, C (218076052)
'  Class name: Address
' *********************************************************************************
Option Strict On
Option Explicit On
Option Infer Off
Public Class frmAddress
    Private Sub btnDone_Click(sender As Object, e As EventArgs) Handles btnDone.Click

        If txtStreetName.Text = "" Then
            MsgBox("Please Enter Street Name")
        ElseIf txtCityTown.Text = "" Then
            MsgBox("Please Enter A City or Town")
        ElseIf txtPostalCode.Text = "" Then
            MsgBox("Please Enter Postal Code")
        ElseIf txtCountry.Text = "" Then
            MsgBox("Please Enter Country ")
        Else
            frmFreeStateGranniesSocialSavings.Show()
            Me.Hide()
        End If
    End Sub
End Class