﻿' ********************************************************************************* 
'  TEAM NUMBER: 13
'  Member 1: MONCHO, R.M (216028656)
'  Member 2: SEKGOTO, N.L (218031731)
'  Member 3: NTOAMPE, L.H (201314444)
'  Member 4: MJEKULA, C (218076052)
'  Class name: frmLogin
' *********************************************************************************
Option Strict On
Option Explicit On
Option Infer Off
Public Class frmLogin

    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click

        ' when the button is clicked then check if the radio button are clicked
        If rdbAdmin.Checked = True Then
            If txtUsername.Text = "Admin" And txtPassword.Text = "Admin" Then  ' checking if the password and username are correct
                frmFreeStateGranniesSocialSavings.Show()  ' show the other  form
                Me.Hide()    ' hide this form
            ElseIf txtUsername.Text = "Admin" And txtPassword.Text = "" Then
                ' if the password text box is blank
                MsgBox("Please Enter Password")
            ElseIf txtUsername.Text = "" And txtPassword.Text = "Admin" Then
                ' if the username text box is blank
                MsgBox("Please Enter Username")
            ElseIf txtUsername.Text = "" And txtPassword.Text = "" Then
                ' if all the text boxes are empty or blank
                MsgBox("Enter Username And Password")
            Else
                ' when the password and username are incorrect
                MsgBox("Invalid Username And Password. Please Provide Correct Details!")

            End If
        ElseIf rdbNonAdmin.Checked = True Then
            If txtUsername.Text = "Betty" And txtPassword.Text = "VanRooi" Then
                frmFreeStateGranniesSocialSavings.Show()
                Me.Hide()
            ElseIf txtUsername.Text = "Betty" And txtPassword.Text = "" Then
                ' if the password text box is blank
                MsgBox("Please Enter Password")
            ElseIf txtUsername.Text = "" And txtPassword.Text = "VanRooi" Then
                ' if the username text box is blank
                MsgBox("Please Enter Username")
            ElseIf txtUsername.Text = "" And txtPassword.Text = "" Then
                ' if all the text boxes are empty or blank
                MsgBox("Enter Username And Password")
            Else
                ' when the password and username are incorrect
                MsgBox("Invalid Username And Password. Please Provide Correct Details!")

            End If
        Else
            MsgBox("Please choose Admin Or Non Admin")
        End If
    End Sub

    Private Sub frmLogin_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        rdbAdmin.Checked = False
        rdbNonAdmin.Checked = False  ' setting radio buttons to a false mode 
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click

        MessageBox.Show("Are you sure you want to Exit?", "Exit", MessageBoxButtons.OKCancel, MessageBoxIcon.Exclamation)
        Me.Close()
    End Sub
End Class
