﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddress
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblStreetName = New System.Windows.Forms.Label()
        Me.lblCityTown = New System.Windows.Forms.Label()
        Me.lblPostalCode = New System.Windows.Forms.Label()
        Me.lblCountry = New System.Windows.Forms.Label()
        Me.txtStreetName = New System.Windows.Forms.TextBox()
        Me.txtCityTown = New System.Windows.Forms.TextBox()
        Me.txtPostalCode = New System.Windows.Forms.TextBox()
        Me.txtCountry = New System.Windows.Forms.TextBox()
        Me.btnDone = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblStreetName
        '
        Me.lblStreetName.AutoSize = True
        Me.lblStreetName.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStreetName.Location = New System.Drawing.Point(29, 27)
        Me.lblStreetName.Name = "lblStreetName"
        Me.lblStreetName.Size = New System.Drawing.Size(81, 13)
        Me.lblStreetName.TabIndex = 0
        Me.lblStreetName.Text = "Street Name "
        '
        'lblCityTown
        '
        Me.lblCityTown.AutoSize = True
        Me.lblCityTown.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCityTown.Location = New System.Drawing.Point(32, 66)
        Me.lblCityTown.Name = "lblCityTown"
        Me.lblCityTown.Size = New System.Drawing.Size(65, 13)
        Me.lblCityTown.TabIndex = 1
        Me.lblCityTown.Text = "City/Town"
        '
        'lblPostalCode
        '
        Me.lblPostalCode.AutoSize = True
        Me.lblPostalCode.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPostalCode.Location = New System.Drawing.Point(32, 103)
        Me.lblPostalCode.Name = "lblPostalCode"
        Me.lblPostalCode.Size = New System.Drawing.Size(75, 13)
        Me.lblPostalCode.TabIndex = 2
        Me.lblPostalCode.Text = "Postal Code"
        '
        'lblCountry
        '
        Me.lblCountry.AutoSize = True
        Me.lblCountry.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCountry.Location = New System.Drawing.Point(35, 148)
        Me.lblCountry.Name = "lblCountry"
        Me.lblCountry.Size = New System.Drawing.Size(50, 13)
        Me.lblCountry.TabIndex = 3
        Me.lblCountry.Text = "Country"
        '
        'txtStreetName
        '
        Me.txtStreetName.Location = New System.Drawing.Point(151, 27)
        Me.txtStreetName.Name = "txtStreetName"
        Me.txtStreetName.Size = New System.Drawing.Size(183, 20)
        Me.txtStreetName.TabIndex = 4
        '
        'txtCityTown
        '
        Me.txtCityTown.Location = New System.Drawing.Point(151, 66)
        Me.txtCityTown.Name = "txtCityTown"
        Me.txtCityTown.Size = New System.Drawing.Size(183, 20)
        Me.txtCityTown.TabIndex = 5
        '
        'txtPostalCode
        '
        Me.txtPostalCode.Location = New System.Drawing.Point(151, 103)
        Me.txtPostalCode.Name = "txtPostalCode"
        Me.txtPostalCode.Size = New System.Drawing.Size(100, 20)
        Me.txtPostalCode.TabIndex = 6
        '
        'txtCountry
        '
        Me.txtCountry.Location = New System.Drawing.Point(151, 148)
        Me.txtCountry.Name = "txtCountry"
        Me.txtCountry.Size = New System.Drawing.Size(183, 20)
        Me.txtCountry.TabIndex = 7
        '
        'btnDone
        '
        Me.btnDone.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnDone.Location = New System.Drawing.Point(97, 198)
        Me.btnDone.Name = "btnDone"
        Me.btnDone.Size = New System.Drawing.Size(143, 40)
        Me.btnDone.TabIndex = 8
        Me.btnDone.Text = "Done"
        Me.btnDone.UseVisualStyleBackColor = True
        '
        'frmAddress
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(342, 250)
        Me.Controls.Add(Me.btnDone)
        Me.Controls.Add(Me.txtCountry)
        Me.Controls.Add(Me.txtPostalCode)
        Me.Controls.Add(Me.txtCityTown)
        Me.Controls.Add(Me.txtStreetName)
        Me.Controls.Add(Me.lblCountry)
        Me.Controls.Add(Me.lblPostalCode)
        Me.Controls.Add(Me.lblCityTown)
        Me.Controls.Add(Me.lblStreetName)
        Me.Name = "frmAddress"
        Me.Text = "Address"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblStreetName As Label
    Friend WithEvents lblCityTown As Label
    Friend WithEvents lblPostalCode As Label
    Friend WithEvents lblCountry As Label
    Friend WithEvents txtStreetName As TextBox
    Friend WithEvents txtCityTown As TextBox
    Friend WithEvents txtPostalCode As TextBox
    Friend WithEvents txtCountry As TextBox
    Friend WithEvents btnDone As Button
End Class
