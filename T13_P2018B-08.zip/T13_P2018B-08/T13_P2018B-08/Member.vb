﻿' ********************************************************************************* 
'  TEAM NUMBER: 13
'  Member 1: MONCHO, R.M (216028656)
'  Member 2: SEKGOTO, N.L (218031731)
'  Member 3: NTOAMPE, L.H (201314444)
'  Member 4: MJEKULA, C (218076052)
'  Class name: frmLogin
' *********************************************************************************
Option Strict On
Option Explicit On
Option Infer Off
Public Class Member
    Private _Surname As String
    Private _Name As String
    Private _Age As Integer
    Private _BirthDay As String
    Private _Address As String
    Private _IDnumber As Integer
    Private _Votes() As Vote
    Private _Loans() As Loan

    ' Property method for Surname 
    Public Property Surname As String
        Get
            Return _Surname
        End Get
        Set(value As String)
            _Surname = value
        End Set
    End Property
    ' Property method for name 
    Public Property Name As String
        Get
            Return _Name
        End Get
        Set(value As String)
            _Name = value
        End Set
    End Property
    ' Property method for age 
    Public Property Age As Integer
        Get
            Return _Age
        End Get
        Set(value As Integer)
            _Age = value
        End Set
    End Property
    ' Property method for Birthday 
    Public Property BirthDay As String
        Get
            Return _BirthDay
        End Get
        Set(value As String)
            _BirthDay = value
        End Set
    End Property
    ' Property method for Address
    Public ReadOnly Property Address As String
        Get
            Return _Address
        End Get

    End Property
    'Property method for ID Numbers
    Public ReadOnly Property IDnumber As Integer
        Get
            Return _IDnumber
        End Get
    End Property
    ' Property method for Votes 
    Public Property Votes(ByVal x As Integer) As Vote
        Get
            Return _Votes(x)
        End Get
        Set(value As Vote)
            _Votes(x) = value
        End Set
    End Property
End Class
