﻿' ********************************************************************************* 
'  TEAM NUMBER: 13
'  Member 1: MONCHO, R.M (216028656)
'  Member 2: SEKGOTO, N.L (218031731)
'  Member 3: NTOAMPE, L.H (201314444)
'  Member 4: MJEKULA, C (218076052)
'  Class name: Address
' *********************************************************************************
Option Strict On
Option Explicit On
Option Infer Off
Public Class Address
    Private _Street As String
    Private _CityTown As String
    Private _PostalCode As Integer
    Private _Country As String
    ' Property method for street
    Public Property Street As String
        Get
            Return _Street
        End Get
        Set(value As String)
            _Street = value
        End Set
    End Property
    ' Property method for City or Town
    Public Property CityTown As String
        Get
            Return _CityTown
        End Get
        Set(value As String)
            _CityTown = value
        End Set
    End Property
    ' Property method for postal code
    Public Property PostalCode As Integer
        Get
            Return _PostalCode
        End Get
        Set(value As Integer)
            _PostalCode = value
        End Set
    End Property
    ' Property method for country
    Public Property Country As String
        Get
            Return _Country
        End Get
        Set(value As String)
            _Country = value
        End Set
    End Property
End Class
